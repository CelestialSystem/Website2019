﻿$('#contact-form').on('submit', function(e) { //Don't foget to change the id form
            $.ajax({
                url: '../php/contact_us/contact_us.php', //===PHP file name====
                data: $(this).serialize(),
                type: 'POST',
                success: function(data) {
                    console.log(data);
                    //Success Message == 'Title', 'Message body', Last one leave as it is
                    swal("¡Success!", "Message sent!", "success");
                },
                error: function(data) {

                    document.getElementById("contact-form").reset();
                    swal("Success!", "Message sent! The form has been submitted successfuly and a representative will get in touch with you soon", "success");

                }

            });
            e.preventDefault();
            //This is to Avoid Page Refresh and Fire the Event "Click"
            document.getElementById("#contact-form").reset();
        });